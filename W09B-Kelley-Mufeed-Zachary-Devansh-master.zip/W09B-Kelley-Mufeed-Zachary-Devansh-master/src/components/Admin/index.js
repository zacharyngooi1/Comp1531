import React from 'react';
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';
import SetUserPermissionsDialog from './SetUserPermissionsDialog';
import RemoveUser from './RemoveUser';

export default function Admin() {

  const [open, setOpen] = React.useState(false);
  const buttonRef = React.useRef();

  const handleClick =(event) => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div>
      <Button
        ref={buttonRef}
        aria-controls="simple-menu"
        aria-haspopup="true"
        onClick={handleClick}
        color="inherit"
      >
        Admin
      </Button>
      <Menu
        id="simple-menu"
        anchorEl={buttonRef.current}
        keepMounted
        open={open}
        onClose={handleClose}
      >
        <SetUserPermissionsDialog>
            <MenuItem onClick={handleClose}>Set User Permissions</MenuItem>
        </SetUserPermissionsDialog>
        <RemoveUser>
            <MenuItem onClick={handleClose}>Remove User</MenuItem>
        </RemoveUser>
        <MenuItem onClick={handleClose}>Close</MenuItem>
      </Menu>
    </div>
  );
}
